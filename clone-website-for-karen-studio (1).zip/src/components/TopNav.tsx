import { useEffect, useRef, useState } from 'react';
import type { ThemeKey } from '../data/themes';
import { themes } from '../data/themes';
import { categories, categoryLabels, type PhotoCategory } from '../data/photos';

type Props = {
  theme: ThemeKey;
  onThemeChange: (t: ThemeKey) => void;
  onNavigate: (p: 'studio' | 'services' | 'contact') => void;
  topText: string;
  filter: 'All' | PhotoCategory;
  onFilterChange: (c: 'All' | PhotoCategory) => void;
};

const NAV_ITEMS: Array<{ id: 'studio' | 'services' | 'contact'; label: string }> = [
  { id: 'studio', label: 'استودیو' },
  { id: 'services', label: 'خدمات' },
  { id: 'contact', label: 'تماس' },
];

export default function TopNav({
  theme, onThemeChange, onNavigate, topText, filter, onFilterChange,
}: Props) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const h = (e: MouseEvent) => {
      if (!wrapRef.current) return;
      if (!wrapRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [open]);

  return (
    <header className="absolute top-0 left-0 right-0 z-40 pointer-events-none">
      <div className="relative flex items-center px-6 py-6 md:px-8">

        {/* ── برند ── */}
        <div className="pointer-events-auto flex items-baseline gap-[12px] leading-none">
          <span
            className="font-logo-b text-[26px] text-white"
            style={{ letterSpacing: '-0.03em', lineHeight: 1 }}
          >
            کارن
          </span>
          <span
            className="text-[10px] tracking-[0.3em] text-white/70"
            style={{ color: topText, lineHeight: 1 }}
          >
            استودیو
          </span>
        </div>

        {/* ── منوی میانی ── */}
        <nav className="pointer-events-auto absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 hidden md:flex items-center gap-10">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className="whitespace-nowrap cursor-pointer text-[12px] tracking-[0.12em] text-white/80 hover:text-white transition-colors leading-none fa-track-wide"
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* ── فیلتر + پوسته ── */}
        <div className="pointer-events-auto ml-auto flex items-center gap-4">

          {/* کنترل فیلتر شیشه‌ای */}
          <div ref={wrapRef} className="relative">
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              className="cursor-pointer flex items-center gap-[6px] h-[32px] pl-[14px] pr-[9px] rounded-full whitespace-nowrap transition-all duration-200"
              style={{
                background: 'rgba(255,255,255,0.10)',
                border: '1px solid rgba(255,255,255,0.22)',
                backdropFilter: 'blur(12px)',
                WebkitBackdropFilter: 'blur(12px)',
                boxShadow: '0 1px 12px -4px rgba(0,0,0,0.18), inset 0 1px 0 rgba(255,255,255,0.12)',
              }}
              aria-label="فیلتر گالری"
            >
              <span className="text-[11px] text-white/85 leading-none">
                {categoryLabels[filter]}
              </span>
              <i
                className={`ri-arrow-down-s-line text-white/60 text-[13px] transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
              />
            </button>

            {/* پاپ‌آور شیشه‌ای */}
            <div
              className="absolute right-0 mt-2 overflow-hidden"
              style={{
                minWidth: '140px',
                borderRadius: '16px',
                background: 'rgba(255,255,255,0.12)',
                border: '1px solid rgba(255,255,255,0.20)',
                backdropFilter: 'blur(28px) saturate(180%)',
                WebkitBackdropFilter: 'blur(28px) saturate(180%)',
                boxShadow:
                  '0 12px 40px -8px rgba(0,0,0,0.28), 0 2px 8px -2px rgba(0,0,0,0.12), inset 0 1px 0 rgba(255,255,255,0.18)',
                transformOrigin: 'top right',
                transform: open ? 'scale(1) translateY(0)' : 'scale(0.96) translateY(-4px)',
                opacity: open ? 1 : 0,
                pointerEvents: open ? 'auto' : 'none',
                transition: 'transform 0.18s cubic-bezier(0.4,0,0.2,1), opacity 0.16s ease',
              }}
            >
              <ul className="py-[6px]">
                {categories.map((c) => {
                  const isActive = filter === c;
                  return (
                    <li key={c}>
                      <button
                        type="button"
                        onClick={() => { onFilterChange(c); setOpen(false); }}
                        className="w-full text-right px-4 py-[9px] cursor-pointer transition-colors whitespace-nowrap flex items-center gap-3"
                        style={{
                          background: isActive ? 'rgba(255,255,255,0.14)' : 'transparent',
                        }}
                      >
                        <span
                          className="block w-1.5 h-1.5 rounded-full flex-shrink-0 transition-colors"
                          style={{ background: isActive ? 'rgba(255,255,255,0.95)' : 'rgba(255,255,255,0.35)' }}
                        />
                        <span
                          className="text-[12px] leading-none transition-colors"
                          style={{ color: isActive ? 'rgba(255,255,255,0.95)' : 'rgba(255,255,255,0.65)' }}
                        >
                          {categoryLabels[c]}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>

          {/* نمونه‌های پوسته */}
          <div className="flex items-center gap-[9px]">
            {(Object.keys(themes) as ThemeKey[]).map((k) => {
              const isActive = theme === k;
              return (
                <button
                  key={k}
                  type="button"
                  onClick={() => onThemeChange(k)}
                  aria-label={themes[k].label}
                  title={themes[k].label}
                  className="cursor-pointer rounded-full transition-all duration-200 hover:scale-110"
                  style={{
                    width: isActive ? '18px' : '14px',
                    height: isActive ? '18px' : '14px',
                    background: themes[k].bg,
                    boxShadow: isActive
                      ? '0 0 0 1.5px rgba(255,255,255,0.95), 0 0 0 2.5px rgba(0,0,0,0.15)'
                      : '0 0 0 1px rgba(255,255,255,0.45)',
                  }}
                />
              );
            })}
          </div>
        </div>
      </div>
    </header>
  );
}
