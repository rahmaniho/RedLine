import { forwardRef, useEffect, useRef, type RefObject } from 'react';
import gsap from 'gsap';
import type { Photo } from '../data/photos';
import { categoryLabels } from '../data/photos';
import type { ThemeKey } from '../data/themes';
import { themes } from '../data/themes';

type Props = {
  photo: Photo | null;
  visible: boolean;
  textReady: boolean;
  onBack: () => void;
  onOpenServices: () => void;
  imageBoxRef: RefObject<HTMLDivElement | null>;
  theme: ThemeKey;
};

const Detail = forwardRef<HTMLDivElement, Props>(function Detail(
  { photo, visible, textReady, onBack, onOpenServices, imageBoxRef, theme },
  ref,
) {
  const textRef = useRef<HTMLDivElement>(null);
  const V = themes[theme];

  useEffect(() => {
    if (!textReady || !textRef.current) return;
    const els = textRef.current.querySelectorAll<HTMLElement>('[data-anim]');
    gsap.fromTo(
      els,
      { opacity: 0, y: 14 },
      { opacity: 1, y: 0, duration: 0.55, ease: 'power2.out', stagger: 0.07 },
    );
  }, [textReady, photo?.id]);

  useEffect(() => {
    if (!textReady && textRef.current) {
      const els = textRef.current.querySelectorAll<HTMLElement>('[data-anim]');
      gsap.set(els, { opacity: 0, y: 14 });
    }
  }, [textReady]);

  const isPortrait = photo?.orientation === 'portrait';

  const coverage =
    photo?.category === 'Wedding'
      ? 'مراسم کامل روز'
      : photo?.category === 'Portrait'
        ? 'جلسهٔ پرتره'
        : photo?.category === 'Travel'
          ? 'سفر نیم‌روز'
          : 'عکاسی در محل';

  const accent = V.bg;
  const INK = '#ffffff';
  const MUTED = 'rgba(255,255,255,0.68)';
  const BORDER = 'rgba(255,255,255,0.18)';

  return (
    <div
      ref={ref}
      className="fixed inset-0"
      style={{
        zIndex: 80,
        visibility: visible ? 'visible' : 'hidden',
        opacity: visible ? 1 : 0,
        pointerEvents: visible ? 'auto' : 'none',
        transition: 'opacity 0.25s ease',
        background: V.radial,
      }}
      aria-hidden={!visible}
    >
      <div className="relative h-full w-full flex items-center px-6 md:px-16 gap-8 md:gap-16">
        <div
          ref={imageBoxRef}
          className="relative shrink-0"
          style={{
            width: isPortrait ? '38vw' : '52vw',
            height: isPortrait ? '78vh' : '62vh',
            maxWidth: '780px',
            borderRadius: '48px',
            overflow: 'hidden',
            background: V.itemBg,
            boxShadow: '0 40px 80px -30px rgba(0,0,0,0.35)',
          }}
        >
          {photo && (
            <img
              src={photo.src}
              alt={photo.title}
              draggable={false}
              className="w-full h-full pointer-events-none"
              style={{ objectFit: 'cover', objectPosition: 'center', display: 'block' }}
            />
          )}
        </div>

        <div ref={textRef} className="flex-1 max-w-md" style={{ color: INK }}>
          <div
            data-anim
            className="inline-flex items-center gap-3 mb-7 px-4 h-[32px] rounded-full"
            style={{ background: 'rgba(255,255,255,0.12)', border: `1px solid ${BORDER}`, backdropFilter: 'blur(8px)' }}
          >
            <span className="block w-1.5 h-1.5 rounded-full" style={{ background: '#fff' }} />
            <span className="text-[11px] text-white/90">
              {photo ? categoryLabels[photo.category] : ''} · {photo?.year}
            </span>
          </div>

          <h1
            data-anim
            className="font-fa-head text-[42px] md:text-[54px] leading-[1.25] mb-5"
            style={{ color: INK }}
          >
            {photo?.title}
          </h1>

          <p
            data-anim
            className="text-[15px] leading-[2] mb-8"
            style={{ color: INK, opacity: 0.84 }}
          >
            {photo?.description}
          </p>

          <div data-anim className="grid grid-cols-2 gap-3 mb-9">
            <div
              className="rounded-3xl px-5 py-4"
              style={{ background: 'rgba(255,255,255,0.09)', border: `1px solid ${BORDER}` }}
            >
              <div className="text-[11px] text-white/55 mb-1.5">دامنهٔ پوشش</div>
              <div className="text-[14px]" style={{ color: INK }}>{coverage}</div>
            </div>
            <div
              className="rounded-3xl px-5 py-4"
              style={{ background: 'rgba(255,255,255,0.09)', border: `1px solid ${BORDER}` }}
            >
              <div className="text-[11px] text-white/55 mb-1.5">قالب</div>
              <div className="text-[14px]" style={{ color: INK }}>نگاتیو + دیجیتال</div>
            </div>
          </div>

          {/* دکمهٔ خدمات */}
          <div data-anim className="mb-6">
            <button
              onClick={onOpenServices}
              className="group inline-flex items-center gap-3 h-[48px] pl-6 pr-5 rounded-full text-[12px] whitespace-nowrap cursor-pointer transition-all hover:scale-[1.02]"
              style={{ background: '#ffffff', color: accent }}
            >
              مشاهدهٔ خدمات و تعرفه‌ها
              <span
                className="w-6 h-6 rounded-full flex items-center justify-center"
                style={{ background: accent, color: '#fff' }}
              >
                <i className="ri-arrow-left-line text-[13px]" />
              </span>
            </button>
          </div>

          {/* بازگشت */}
          <div data-anim>
            <button
              onClick={onBack}
              className="group inline-flex items-center gap-2 text-[11px] whitespace-nowrap cursor-pointer transition-opacity hover:opacity-100"
              style={{ color: MUTED }}
            >
              <i className="ri-arrow-right-line text-[13px] transition-transform group-hover:-translate-x-0.5" />
              بازگشت به گالری
            </button>
          </div>
        </div>
      </div>

      <div className="absolute top-0 left-0 right-0 flex items-center justify-between px-6 md:px-8 py-6 pointer-events-none">
        <div className="flex items-baseline gap-[12px] leading-none">
          <span className="font-logo-b text-[26px]" style={{ letterSpacing: '-0.03em', lineHeight: 1, color: '#fff' }}>
            کارن
          </span>
          <span className="text-[10px] text-white/55" style={{ lineHeight: 1 }}>
            نمای جزئیات
          </span>
        </div>
        <span className="text-[11px] text-white/60">
          {photo ? `شمارهٔ ${photo.id.replace('photo-', '')}` : ''}
        </span>
      </div>
    </div>
  );
});

export default Detail;
